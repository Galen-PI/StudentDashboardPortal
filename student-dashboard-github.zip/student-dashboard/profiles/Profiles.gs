// ============================================================
// Profiles.gs — Shared profile helpers
// ------------------------------------------------------------

// Cap on how many points any ONE category (Academic, a single Trade, or
// WIR/Intervention) can contribute to the total score. Many checks within
// a category are correlated symptoms of the same one real problem (e.g.
// "behind pace" + "low completion" + "no hours this week" usually all
// describe one student who simply isn't engaging academically right now)
// — without a cap, that one real problem gets counted 2-3x and pushes
// scores into "Needs Attention" much faster than the situation actually
// warrants. The cap lets a single bad category get you close to Needs
// Attention on its own, but not there alone — reaching HIGH now generally
// means more than one real, independent problem, not one problem
// described three different ways.
const RISK_CATEGORY_CAP = 45;

// Separate, smaller cap for Time & Data Factors — this category's checks
// are already mutually exclusive by construction (see dataScore below),
// so 30 is just a realistic ceiling matching this category's actual
// historical max, kept as a safety net rather than a real behavior change.
const RISK_DATA_CATEGORY_CAP = 30;

// ── Risk calculation ──────────────────────────────────────────
function _calcRisk(academic, trades, time, hsComplete, tradeComplete, completedTrades, intervention, scheduledAcademicHours) {
  const flags = [];
  // Parallel breakdown of {label, points} for every flag that actually
  // fired, in the order applied — powers the score hover tooltip so
  // staff can see exactly what added up to the total, not just the flags.
  const flagsDetailed = [];
  let score   = 0;

  // Pushes to both flags (plain text, unchanged shape everything else
  // already reads) and flagsDetailed (adds the point value), and returns
  // the points so the call site can add it to whichever category
  // accumulator it belongs to in one line.
  function addFlag(label, points) {
    flags.push(label);
    flagsDetailed.push({ label, points });
    return points;
  }

  // Completion guard -- a student marked academically complete
  // should never be scored on academic pace/hours/deadline data,
  // even if that data is stale (e.g. course-data recompute hasn't
  // caught up yet after a course was just finished). Without this,
  // a "Complete" tag and a "Needs Attention" risk score could
  // display simultaneously and contradict each other.
  // Scheduled-hours data, when available, is strictly more precise than
  // the generic "no hours logged" check below (it knows how many
  // periods were actually expected, not just whether hours were zero).
  // Using both was double-counting the same underlying fact — a
  // student with zero hours this week AND schedule data on file could
  // get +15 (generic) AND +25 (scheduled) for one missed week. The
  // generic check now only fires when there's no schedule data to be
  // more precise with.
  const hasScheduleData = scheduledAcademicHours !== null && scheduledAcademicHours > 0;

  // Academic Factors AND WIR/Intervention Factors share ONE capped group.
  // WIR is strictly an academic-progress signal — it carries no weight
  // toward Trades at all — and a CRITICAL/HIGH WIR report is usually
  // describing the same underlying academic struggle the pace/completion
  // checks below already catch, just from a staff observation instead of
  // a data metric. Capping them together (rather than each getting its
  // own separate 45) keeps one academic problem from counting twice just
  // because it shows up in both the data and a staff report.
  let academicScore = 0;

  if (academic && !hsComplete) {
    const pace = String(academic.pace || '').toLowerCase();
    if (pace.includes('at risk')) {
      academicScore += addFlag('Academic at-risk pace', 40);
    } else if (pace.includes('behind') || pace.includes('slow')) {
      academicScore += addFlag('Behind academic pace', 30);
    }
    if (academic.percent !== null && academic.percent < 50) {
      academicScore += addFlag('Low academic completion (<50%)', 20);
    }
    if (academic.daysToGrad !== null && academic.daysToGrad < 30
        && academic.percent !== null && academic.percent < 90) {
      academicScore += addFlag('Graduation deadline approaching', 25);
    }
    if (!hasScheduleData) {
      const thisWk = academic.thisWeekHours;
      if (thisWk !== 'NWH' && (thisWk === null || thisWk === 0)) {
        academicScore += addFlag('No academic hours logged this week', 15);
      }
    }
  }

  if (trades && trades.length) {
    trades.forEach(t => {
      const tradeName  = t.tarName || 'Trade';
      const isBCT      = tradeName.toUpperCase() === 'BCT';
      const isComplete = (t.overallPct !== null && t.overallPct >= 100)
                       || completedTrades.includes(tradeName);

      if (isComplete) { flags.push(tradeName + ': Trade Complete'); return; }

      // This trade's own points accumulate here, capped independently of
      // any other trade the student is enrolled in — a second stalled
      // trade is a genuinely separate problem and should still be able
      // to add to the total, but each trade's own correlated symptoms
      // (pace gap + low progress + stalled gain, all describing the same
      // one stalled trade) shouldn't multiply past the cap by themselves.
      let tradeScore = 0;

      if ((t.paceGap || 0) < -10) {
        tradeScore += addFlag(tradeName + ': large pace gap (' + t.paceGap + '%)', 20);
      }
      if (String(t.status || '').toLowerCase().match(/inactive|withdrawn/)) {
        tradeScore += addFlag(tradeName + ': inactive/withdrawn', 15);
      }
      if (t.overallPct !== null && t.overallPct < 25
          && t.daysToETAR !== null && t.daysToETAR < 60) {
        tradeScore += addFlag(tradeName + ': very low progress near ETAR deadline', 25);
      }

      const threshold = isBCT ? 1.5 : 3.0;
      const monthly   = t.monthlyProgress || [];
      const scorable  = monthly.filter(m =>
        !m.addedPostFirst &&
        m.overallGain !== null &&
        (m.endOverallPct === null || m.endOverallPct < 100)
      );
      if (scorable.length) {
        const recent        = scorable.slice(-2);
        const stalledMonths = recent.filter(m => m.overallGain < threshold);
        const lastMonth     = recent[recent.length - 1];
        const lastGain      = lastMonth ? lastMonth.overallGain : null;
        const lastEndPct    = lastMonth ? lastMonth.endOverallPct : null;
        const consecutiveStall = stalledMonths.length === 2 && recent.length === 2;
        const singleStall      = stalledMonths.length >= 1 && !consecutiveStall;

        if (consecutiveStall) {
          const avgGain = (recent.reduce((a, m) => a + m.overallGain, 0) / recent.length).toFixed(1);
          tradeScore += addFlag(tradeName + ': stalled for 2 consecutive months (avg gain ' + avgGain + '%, expected ≥' + threshold + '%)', isBCT ? 15 : 25);
          if (lastEndPct !== null && lastEndPct < 25) {
            tradeScore += addFlag(tradeName + ': stalled with very low overall completion (' + lastEndPct + '%)', 10);
          }
        } else if (singleStall) {
          tradeScore += addFlag(tradeName + ': low monthly gain (' + (lastGain !== null ? lastGain.toFixed(1) : '?') + '% — expected ≥' + threshold + '%)', isBCT ? 10 : 15);
          if (lastEndPct !== null && lastEndPct < 25) {
            tradeScore += addFlag(tradeName + ': low gain with low overall completion (' + lastEndPct + '%)', 10);
          }
        }
      }

      score += Math.min(tradeScore, RISK_CATEGORY_CAP);
    });
  }

  if ((!trades || !trades.length) && completedTrades.length) {
    completedTrades.forEach(name => { flags.push(name + ': Trade Complete'); });
  }

  // Scheduled hours comparison (weekdays only) — the precise version
  // of the no-hours-logged check above; see hasScheduleData note.
  // Still accumulates into academicScore so it's part of the same capped
  // Academic Factors group.
  if (academic && !hsComplete && hasScheduleData) {
    const thisWk = academic.thisWeekHours;
    const actual = (thisWk === 'NWH' || thisWk === null) ? 0 : +thisWk;
    if (actual === 0) {
      academicScore += addFlag('No hours logged — scheduled for ' + scheduledAcademicHours + ' academic periods this week', 25);
    } else if (actual < scheduledAcademicHours * 0.5) {
      academicScore += addFlag('Behind scheduled hours — logged ' + actual.toFixed(1) + 'h of ' + scheduledAcademicHours + ' scheduled academic periods', 15);
    }
  }

  // hasAnyData is needed here (moved up) so the Time & Data checks below
  // can avoid double-describing the same "nothing on file for this
  // student" fact two different ways.
  const hasAnyData = !!academic || (trades && trades.length) || !!time || hsComplete || tradeComplete;

  // All Time & Data Factors accumulate here, then get capped as one group.
  // In practice these three checks are already mutually exclusive by
  // construction (minimal-hours requires time data to exist; no-time-data
  // and no-data-at-all require it to be absent, and are split by whether
  // OTHER data exists) — the cap is a safety net so a future addition to
  // this category can't reintroduce the same stacking problem the other
  // categories had.
  let dataScore = 0;
  const consideredComplete = hsComplete || tradeComplete;
  if (time) {
    if ((time.totalHours || 0) < 1) {
      dataScore += addFlag('Minimal total logged time', 20);
    }
  } else if (!consideredComplete && hasAnyData) {
    // Only flagged when there IS other data on file but specifically no
    // time data — if there's truly nothing at all, "No academic or
    // trades data" below already says that, more completely, once.
    dataScore += addFlag('No time data found', 10);
  }

  // WIR/Intervention Factors — strictly academic (never applies to
  // Trades), so these fold into academicScore and share its cap rather
  // than getting a separate allowance of their own. See note above.
  if (intervention) {
    const adminP  = String(intervention.adminPriority || intervention.priority || '').toUpperCase();
    const urgency = String(intervention.urgency || '').toUpperCase();
    const cStatus = String(intervention.caseStatus || '').toLowerCase();
    if      (adminP === 'CRITICAL') { academicScore += addFlag('Intervention: CRITICAL admin priority this week', 40); }
    else if (adminP === 'HIGH')     { academicScore += addFlag('Intervention: HIGH admin priority this week', 25); }
    else if (adminP === 'MEDIUM')   { academicScore += addFlag('Intervention: MEDIUM admin priority this week', 10); }
    if      (urgency === 'IMMEDIATE') { academicScore += addFlag('Intervention: IMMEDIATE urgency', 20); }
    else if (urgency === 'URGENT')    { academicScore += addFlag('Intervention: URGENT', 10); }
    if (cStatus === 'open') { academicScore += addFlag('Active open intervention case', 15); }
  }

  score += Math.min(academicScore, RISK_CATEGORY_CAP);

  if (!hasAnyData) { dataScore += addFlag('No academic or trades data', 20); }
  score += Math.min(dataScore, RISK_DATA_CATEGORY_CAP);

  score = Math.min(score, 100);
  const level = !hasAnyData ? 'UNKNOWN'
              : score >= 60  ? 'HIGH'
              : score >= 30  ? 'MEDIUM'
              : 'LOW';

  return { level, score, flags, flagsDetailed, overridden: false };
}

// ── Apply manual overrides ────────────────────────────────────
function _applyOverrides(profile, overridesByStudent) {
  const ov = overridesByStudent[profile.id];
  if (!ov) return profile;

  ov.forEach(o => {
    switch (o.type) {
      case 'academic_status': profile.academicStatusOverride = o.value; break;
      case 'trade_projected_end':     profile.tradeProjectedEndOverride     = o.value; break;
      case 'trade_enrollment_status': profile.tradeEnrollmentStatusOverride = o.value; break;
      case 'trade_status':    profile.tradeStatusOverride    = o.value; break;
      case 'trade_name':      profile.tradeNameOverride      = o.value; break;
      case 'hsd_class':       profile.hsdOverride            = o.value; break;
      case 'status_tag':      profile.statusTag              = o.value; break;
      case 'staff_note':      profile.staffNote              = o.value; break;
      case 'risk_level':
        profile.risk.level    = o.value;
        profile.risk.overridden = true;
        break;
      case 'flag_add':
        if (o.value) profile.risk.flags.push(o.value);
        break;
      case 'flag_remove':
        if (o.value) profile.risk.flags = profile.risk.flags.filter(f => !f.includes(o.value));
        break;
      case 'last_modified':
        if (o.value) profile.lastModified = o.value;
        break;
      case 'note':
        if (!profile.notes) profile.notes = [];
        profile.notes.push({
          text:  String(o.value || '').trim(),
          setBy: String(o.setBy || '').trim(),
          date:  o.date ? (o.date instanceof Date ? o.date.toISOString() : String(o.date)) : null,
        });
        break;
      case 'progress_snapshot':
        try {
          const snap = JSON.parse(o.value);
          if (!profile.progressSnapshots) profile.progressSnapshots = [];
          profile.progressSnapshots.push(snap);
          if (!profile.progressSnapshot || snap.date > profile.progressSnapshot.date) {
            profile.progressSnapshot = snap;
          }
        } catch(e) { /* ignore malformed */ }
        break;
    }
  });

  // Stale detection — only for active students with snapshot history
  if (profile.progressSnapshot && !profile.hsComplete && !profile.tradeComplete) {
    const snap      = profile.progressSnapshot;
    const snapDate  = new Date(snap.date);
    const daysSince = (Date.now() - snapDate.getTime()) / 86400000;

    if (daysSince >= STALE_THRESHOLD_DAYS) {
      const currentAcPct = profile.academic ? profile.academic.percent : null;
      const currentTrPct = profile.trades && profile.trades.length ? profile.trades[0].overallPct : null;
      const acStale = currentAcPct !== null && snap.acPct !== null && currentAcPct === snap.acPct && profile.hasAcademic;
      const trStale = currentTrPct !== null && snap.trPct !== null && currentTrPct === snap.trPct && profile.hasTrades;

      if (acStale || trStale) {
        profile.isStale = true;
        const staleWeeks = Math.floor(daysSince / 7);
        if (acStale && trStale) {
          profile.risk.flags.push('No academic or trades progress in ' + staleWeeks + '+ weeks');
        } else if (acStale) {
          profile.risk.flags.push('Academic % unchanged for ' + staleWeeks + '+ weeks');
        } else {
          profile.risk.flags.push('Trades % unchanged for ' + staleWeeks + '+ weeks');
        }
        if (!profile.risk.overridden) {
          profile.risk.score = Math.min(profile.risk.score + 15, 100);
          if      (profile.risk.score >= 60 && profile.risk.level !== 'HIGH')   profile.risk.level = 'HIGH';
          else if (profile.risk.score >= 30 && profile.risk.level === 'LOW')    profile.risk.level = 'MEDIUM';
        }
      }
    }
  }
  return profile;
}
function _shouldAutoClearNotStarted_(profile, type) {
  if (type === 'academic_status') {
    return profile.academicStatusOverride === 'NOT_STARTED' &&
           !!(profile.academic && profile.academic.start && profile.academic.targetDate);
  }
  if (type === 'trade_status') {
    return profile.tradeStatusOverride === 'NOT_STARTED' &&
           profile.hasTrades === true;
  }
  return false;
}

// Writes a fresh, blank override row for each entry — same effect as
// staff clicking "Clear" on that override, just done automatically.
// Overrides are last-write-wins per student+type, so appending a
// blank one here overrides the old NOT_STARTED value going forward.

// ── Compute risk trend arrow ──────────────────────────────────
function _computeRiskTrend(profile) {
  const snaps = (profile.progressSnapshots || [])
    .filter(s => s.score !== null && s.score !== undefined);
  if (!snaps.length) return;
  snaps.sort((a, b) => (a.date || '') < (b.date || '') ? -1 : 1);
  const delta = profile.risk.score - snaps[0].score;
  profile.riskTrend = delta > 5 ? 'up' : delta < -5 ? 'down' : 'stable';
}

// ── Apply merges ──────────────────────────────────────────────
function _applyMerges(profiles, mergeMap) {
  if (!mergeMap || !Object.keys(mergeMap).length) return profiles;
  const byId = {};
  profiles.forEach(p => { byId[p.id] = p; });

  Object.keys(mergeMap).forEach(sourceId => {
    const source = byId[sourceId];
    const target = byId[mergeMap[sourceId]];
    if (!source || !target) return;

    if (!target.academic  && source.academic)  { target.academic   = source.academic;  target.hasAcademic  = true; }
    if ((!target.trades || !target.trades.length) && source.trades && source.trades.length) {
      target.trades   = source.trades;  target.hasTrades   = true;
    }
    if (!target.time       && source.time)       { target.time       = source.time;      target.hasTime       = true; }
    if (!target.intervention && source.intervention) {
      target.intervention   = source.intervention; target.hasIntervention = true;
    }
    if (source.completedTrades && source.completedTrades.length) {
      target.completedTrades = [...new Set([...(target.completedTrades || []), ...source.completedTrades])];
      target.tradeComplete   = target.tradeComplete || source.completedTrades.length > 0;
    }
    if (!target.hsComplete && source.hsComplete) target.hsComplete = true;
    if (source.lastModified && (!target.lastModified || source.lastModified > target.lastModified)) {
      target.lastModified = source.lastModified;
    }

    const wasOverridden = target.risk && target.risk.overridden;
    target.risk = _calcRisk(
      target.academic, target.trades, target.time,
      target.hsComplete, target.tradeComplete, target.completedTrades || [],
      target.intervention, target.scheduledAcademicHours
    );
    if (wasOverridden) target.risk.overridden = true;
  });

  return profiles.filter(p => !mergeMap[p.id]);
}

// ── Summary metrics ───────────────────────────────────────────
function computeSummaryMetrics(profiles) {
  const total      = profiles.length;
  const riskCounts = { HIGH: 0, MEDIUM: 0, LOW: 0, UNKNOWN: 0 };
  profiles.forEach(p => { riskCounts[p.risk?.level || 'UNKNOWN']++; });
  const withIntervention = profiles.filter(p => p.hasIntervention).length;
  const unmapped         = profiles.filter(p => p.mappingMissing).length;
  const stale            = profiles.filter(p => p.isStale).length;
  const hasNotes         = profiles.filter(p => p.notes && p.notes.length).length;
  const avgAcademicPct = _avg(
    profiles.filter(p => p.academic && p.academic.percent !== null).map(p => p.academic.percent)
  );
  const avgTradesPct = _avg(
    profiles.filter(p => p.trades && p.trades.length && p.trades[0].overallPct !== null).map(p => p.trades[0].overallPct)
  );

  return {
    total, riskCounts,
    withAcademic:    profiles.filter(p => p.hasAcademic).length,
    withTrades:      profiles.filter(p => p.hasTrades).length,
    withBoth:        profiles.filter(p => p.hasAcademic && p.hasTrades).length,
    withTime:        profiles.filter(p => p.hasTime).length,
    withIntervention,
    unmapped,
    tradeComplete:   profiles.filter(p => p.tradeComplete).length,
    overridden:      profiles.filter(p => p.risk && p.risk.overridden).length,
    stale,
    hasNotes,
    avgAcademicPct:  avgAcademicPct !== null ? +avgAcademicPct.toFixed(1) : null,
    avgTradesPct:    avgTradesPct   !== null ? +avgTradesPct.toFixed(1)   : null,
  };
}