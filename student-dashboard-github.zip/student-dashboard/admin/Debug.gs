// ============================================================
// Debug.gs — Debug and diagnostic functions (Vault-native)
// ============================================================

// ── Dashboard / Cache ─────────────────────────────────────────

function debugForceFullClear() {
  const cache = CacheService.getScriptCache();
  const results = [];

  // ── Chunked / single-key caches ──────────────────────────────
  const hadDashboard = cache.get('dashboardData_meta') !== null;
  _cacheRemoveChunked(cache, 'dashboardData');
  results.push({ label: 'Dashboard data', cleared: hadDashboard });

  const hadProductivity = cache.get('productivityData_meta') !== null;
  _cacheRemoveChunked(cache, 'productivityData');
  results.push({ label: 'Productivity data', cleared: hadProductivity });

  const hadCatalogue = cache.get('VAULT_COURSE_CATALOGUE') !== null;
  cache.remove('VAULT_COURSE_CATALOGUE');
  results.push({ label: 'Course catalogue', cleared: hadCatalogue });

  const hadMasterHours = cache.get('VAULT_MASTER_SCHEDULE_HOURS') !== null;
  cache.remove('VAULT_MASTER_SCHEDULE_HOURS');
  results.push({ label: 'Master schedule hours', cleared: hadMasterHours });

  const hadSystemFlag = cache.get('systemEnabled') !== null;
  cache.remove('systemEnabled');
  results.push({ label: 'System status flag', cleared: hadSystemFlag });

  // ── Per-student / per-staff keys ─────────────────────────────
  // CacheService has no key-listing API, so these can only be checked by
  // reconstructing the keys from the known ID lists (Name Mapping /
  // Staff Roles) and testing each. Any cache key that isn't derivable
  // this way can't be itemized — there shouldn't be any left, but if a
  // future cache key is added elsewhere, add its bucket here too.
  let scheduleCount = 0;
  try {
    const nameMap = readVaultSheetAsObjects_(VAULT_SHEET_NAME_MAPPING, VAULT_NAME_MAPPING_HEADERS);
    const studentIds = nameMap.map(r => String(r.studentId || '').trim()).filter(Boolean);
    const scheduleKeys = studentIds.map(id => 'schedule_' + id);
    const found = [];
    for (let i = 0; i < scheduleKeys.length; i += 100) {
      const hits = cache.getAll(scheduleKeys.slice(i, i + 100));
      found.push(...Object.keys(hits));
    }
    scheduleCount = found.length;
    for (let i = 0; i < found.length; i += 100) cache.removeAll(found.slice(i, i + 100));
  } catch(e) {
    Logger.log('Schedule cache scan failed (non-fatal): ' + e.message);
  }
  results.push({ label: 'Schedule cache', cleared: scheduleCount > 0, count: scheduleCount });

  let staffCount = 0;
  try {
    const adminSS = SpreadsheetApp.openById(SS_ADMIN);
    const sheet   = adminSS.getSheetByName(SHEET_STAFF_ROLES);
    if (sheet) {
      const lastRow = sheet.getLastRow();
      const employeeIds = lastRow >= 2
        ? sheet.getRange(2, 1, lastRow - 1, 1).getValues().map(r => String(r[0] || '').trim()).filter(Boolean)
        : [];
      const staffKeys = employeeIds.map(id => 'staffRole_' + id);
      const found = [];
      for (let i = 0; i < staffKeys.length; i += 100) {
        const hits = cache.getAll(staffKeys.slice(i, i + 100));
        found.push(...Object.keys(hits));
      }
      staffCount = found.length;
      for (let i = 0; i < found.length; i += 100) cache.removeAll(found.slice(i, i + 100));
    }
  } catch(e) {
    Logger.log('Staff role cache scan failed (non-fatal): ' + e.message);
  }
  results.push({ label: 'Staff login cache', cleared: staffCount > 0, count: staffCount });

  Logger.log('Itemized cache clear: ' + JSON.stringify(results));
  return { success: true, results };
}

// Runs a full dashboard rebuild and logs timing for each step.
function debugRebuildTiming() {
  const t0 = Date.now();
  const data = _rebuildDashboardData();
  Logger.log('Total time: ' + (Date.now() - t0) + 'ms');
  Logger.log('Profiles built: ' + (data.profiles || []).length);
  Logger.log('Error: ' + (data.error || 'none'));
}

// ── Profiles ──────────────────────────────────────────────────

// Logs a summary of all profiles — useful for checking counts
// and spotting unmapped or missing students.
function debugProfileSummary() {
  const data = getDashboardData();
  if (data.error) { Logger.log('ERROR: ' + data.error); return; }

  const profiles = data.profiles || [];
  Logger.log('=== PROFILE SUMMARY ===');
  Logger.log('Total profiles: ' + profiles.length);
  Logger.log('HS students:    ' + profiles.filter(p => p.academic && p.academic.type === 'HS').length);
  Logger.log('HiSET students: ' + profiles.filter(p => p.academic && p.academic.type === 'HISET').length);
  Logger.log('Trades only:    ' + profiles.filter(p => !p.hasAcademic && p.hasTrades).length);
  Logger.log('Trade complete: ' + profiles.filter(p => p.tradeComplete).length);
  Logger.log('HS complete:    ' + profiles.filter(p => p.hsComplete).length);
  Logger.log('Unmapped:       ' + profiles.filter(p => p.mappingMissing).length);
  Logger.log('HIGH risk:      ' + profiles.filter(p => p.risk && p.risk.level === 'HIGH').length);
  Logger.log('MEDIUM risk:    ' + profiles.filter(p => p.risk && p.risk.level === 'MEDIUM').length);
  Logger.log('LOW risk:       ' + profiles.filter(p => p.risk && p.risk.level === 'LOW').length);
  Logger.log('Has TABE:       ' + profiles.filter(p => p.hasTABE).length);
  Logger.log('Has courseData: ' + profiles.filter(p => p.courseData).length);
}

// Logs all profiles that are missing from the Name Mapping sheet.
function debugUnmappedStudents() {
  const data = getDashboardData();
  if (data.error) { Logger.log('ERROR: ' + data.error); return; }

  const unmapped = (data.profiles || []).filter(p => p.mappingMissing);
  Logger.log('Unmapped students (' + unmapped.length + '):');
  unmapped.forEach(p => {
    Logger.log('  ' + p.displayName +
      ' | academic: ' + (p.hasAcademic ? p.academic.type : 'none') +
      ' | trades: '   + (p.hasTrades ? (p.trades[0] && p.trades[0].tarName) : 'none'));
  });
}

// Looks up a specific student by display name and logs their full profile.
// Usage: change the name, then run from the editor.
function debugStudentProfile() {
  const STUDENT_NAME = 'Last, First'; // ← change this

  const data = getDashboardData();
  if (data.error) { Logger.log('ERROR: ' + data.error); return; }

  const profile = (data.profiles || []).find(p =>
    p.displayName.toLowerCase() === STUDENT_NAME.toLowerCase()
  );

  if (!profile) {
    Logger.log('No profile found for: ' + STUDENT_NAME);
    Logger.log('Available names (first 20):');
    (data.profiles || []).slice(0, 20).forEach(p => Logger.log('  ' + p.displayName));
    return;
  }

  Logger.log('=== PROFILE: ' + profile.displayName + ' ===');
  Logger.log('ID:           ' + profile.id);
  Logger.log('academicId:   ' + profile.academicId);
  Logger.log('Risk:         ' + profile.risk.level + ' (' + profile.risk.score + ')');
  Logger.log('HS Complete:  ' + profile.hsComplete);
  Logger.log('Trade Complete: ' + profile.tradeComplete);
  Logger.log('Has TABE:     ' + profile.hasTABE);
  Logger.log('Has courseData: ' + !!profile.courseData);
  if (profile.academic) {
    Logger.log('Academic:     ' + profile.academic.type +
      ' | ' + profile.academic.percent + '%' +
      ' | credits: ' + profile.academic.credits +
      ' | graduation: ' + profile.academic.graduation);
  }
  if (profile.trades && profile.trades.length) {
    profile.trades.forEach(t => {
      Logger.log('Trade:        ' + t.tarName + ' | ' + t.overallPct + '%');
    });
  }
  if (profile.courseData) {
    Logger.log('Course data:  ' + profile.courseData.remainingCredits + ' credits left' +
      ' | ' + profile.courseData.remainingHours + 'h remaining' +
      ' | next: ' + profile.courseData.nextCourse);
  }
  Logger.log('Risk flags:   ' + (profile.risk.flags || []).join(' | '));
}

// ── HS Graduation ─────────────────────────────────────────────

// Logs all HS students and their graduation dates so you can
// see what format and values are actually on the profiles.
function debugHSGraduationDates() {
  const data = getDashboardData();
  if (data.error) { Logger.log('ERROR: ' + data.error); return; }

  const profiles = data.profiles || [];
  const hs = profiles.filter(p => p.academic && p.academic.type === 'HS' && !p.hsComplete);

  Logger.log('Total active HS students: ' + hs.length);
  Logger.log('');

  const now        = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const monthEnd   = new Date(now.getFullYear(), now.getMonth() + 1, 0);

  Logger.log('Current month window: ' + monthStart.toDateString() + ' → ' + monthEnd.toDateString());
  Logger.log('');

  hs.forEach(p => {
    const grad    = p.academic.graduation;
    const parsed  = grad ? _parseLocalDate(grad) : null;
    const inMonth = parsed && parsed >= monthStart && parsed <= monthEnd;
    Logger.log(
      p.displayName +
      ' | graduation: "' + grad + '"' +
      ' | parsed: ' + (parsed ? parsed.toDateString() : 'INVALID') +
      ' | in month: ' + inMonth +
      ' | credits: ' + p.academic.credits +
      ' | %: ' + p.academic.percent +
      ' | courseData: ' + (p.courseData ? 'yes (' + p.courseData.remainingCredits + ' left)' : 'null')
    );
  });
}

// Runs the HS graduation prediction model and logs a full report.
function debugHSGraduationPredictions() {
  const result = getHSGraduationPredictions();
  if (result.error) { Logger.log('ERROR: ' + result.error); return; }

  Logger.log('=== HS GRADUATION PREDICTIONS — ' + result.month + ' ===');
  Logger.log('Weeks left in month: ' + result.weeksLeft);
  Logger.log('Students scheduled to graduate this month: ' + result.graduates.length);
  Logger.log('');

  if (!result.graduates.length) {
    Logger.log('No students have a graduation date this month.');
    return;
  }

  result.graduates.forEach((g, i) => {
    Logger.log((i + 1) + '. ' + g.name + '  [' + g.likelihood + ' — ' + g.score + '/100]');
    Logger.log('   Grad date:    ' + g.graduationDate);
    Logger.log('   Credits left: ' + g.creditsLeft +
      ' | Remaining hours: ' + g.remainingHours +
      ' | Course data: ' + (g.remainingHours !== null ? 'attached' : 'not attached'));
    Logger.log('   Weekly avg:   ' + g.weeklyAvgHours + 'h' +
      ' | Monthly rate: ' + g.monthlyRate + ' credits/mo' +
      ' | Projected short: ' + g.projectedCreditsAtMonthEnd);
    Logger.log('   Pace: ' + g.pace +
      ' | Academic %: ' + g.academicPct + '%' +
      ' | Risk: ' + g.riskLevel);
    Logger.log('   Next course: ' + (g.nextCourse || '—') +
      ' | Target: ' + (g.nextCourseTarget || '—'));
    Logger.log('   Signals: ' + g.notes.join(' · '));
    Logger.log('');
  });
}

// DEPRECATED — checks the frozen 'Student Course Data' sheet, which
// CourseSync.gs's 2026-07-15 redesign stopped reading/writing entirely
// (course data is now computed LIVE from Transcript Rows on every
// dashboard rebuild). This function's "FOUND"/"YES" results reflect
// that old frozen snapshot, not what Cards/Overview actually use today
// — they will not help diagnose a live course-data or target-date
// issue. Use debugCourseDataLookup(studentId) in CourseSync.gs instead,
// which checks the real, currently-used live path.
function debugCourseDataLookup_dashboard() {
  Logger.log('WARNING: this checks the deprecated, frozen Student Course Data sheet — ' +
    'not the live path Cards/Overview actually use. Use debugCourseDataLookup(studentId) ' +
    'in CourseSync.gs instead.');
  const data = getDashboardData();
  if (data.error) { Logger.log('ERROR: ' + data.error); return; }

  const profiles = (data.profiles || []).filter(p =>
    p.academic && p.academic.type === 'HS' && !p.hsComplete
  );

  const courseDataRows = readVaultSheetAsObjects_(VAULT_SHEET_STUDENT_COURSE_DATA, VAULT_STUDENT_COURSE_DATA_HEADERS);
  const idsInSheet = courseDataRows.map(r => String(r.studentId || '').trim());

  Logger.log('Student IDs in Student Course Data sheet (first 10):');
  idsInSheet.slice(0, 10).forEach(id => Logger.log('  "' + id + '"'));
  Logger.log('');

  Logger.log('First 10 HS profile course data lookups (joined on academicId):');
  profiles.slice(0, 10).forEach(p => {
    const inSheet = idsInSheet.includes(String(p.academicId || '').trim());
    Logger.log('  "' + p.displayName + '" (' + p.academicId + ')' +
      ' | courseData: ' + (p.courseData ? 'FOUND' : 'null') +
      ' | id in sheet: ' + (inSheet ? 'YES' : 'NO'));
  });
}

// ── Scheduled Periods ─────────────────────────────────────────

// Shows how scheduled academic periods are being counted for
// specific students, using the same Vault schedule reader the
// dashboard itself uses (getStudentSchedule → VAULT_SHEET_WEEKLY_SCHEDULE).
function debugScheduledPeriods() {
  const data = getDashboardData();
  if (data.error) { Logger.log('ERROR: ' + data.error); return; }

  // ← Update these names as needed
  const names = ['Last, First A', 'Last, First B'];

  const ACADEMIC_NAMES = ['HSD 2', 'HSD3', 'HSE/HSD1'];
  const VALID_PERIODS  = { M:[1,2,3,5,6], T:[1,2,3,5,6,7], W:[1,2,3,5,6], TH:[1,2,3,5,6,7], F:[1,2,3,5,6,7] };

  names.forEach(name => {
    const profile = (data.profiles || []).find(p => p.displayName === name);
    if (!profile) { Logger.log(name + ': profile not found'); return; }

    Logger.log(name + ':');
    Logger.log('  scheduledAcademicHours = ' + profile.scheduledAcademicHours);
    Logger.log('  academicId = ' + profile.academicId);

    const result = getStudentSchedule(profile.academicId);
    if (!result || result.error || !result.schedule) {
      Logger.log('  No schedule found for ID: ' + profile.academicId +
        (result && result.error ? ' | error: ' + result.error : ''));
      return;
    }

    let count = 0;
    Object.entries(VALID_PERIODS).forEach(([day, periods]) => {
      periods.forEach(periodNum => {
        const entry = (result.schedule['Period ' + periodNum] || {})[day];
        if (!entry) return;
        const isAcademic = ACADEMIC_NAMES.some(n => (entry.class || '').toLowerCase().includes(n.toLowerCase()));
        if (isAcademic) {
          count++;
          Logger.log('  ACADEMIC: ' + day + ' Period ' + periodNum + ' = ' + entry.class);
        }
      });
    });
    Logger.log('  Total academic periods counted: ' + count);
    Logger.log('');
  });
}

// ── Transcript Row Inspector ───────────────────────────────────

// Vault replacement for the old per-student Edgenuity-sheet
// inspector. There's no per-student sheet anymore — course data
// for every student now lives in one flat Vault table
// (VAULT_SHEET_TRANSCRIPT_ROWS), keyed by studentId. This logs
// every transcript row on file for one student.
// Update STUDENT_ID to an academicId from Name Mapping.
function debugStudentTranscriptRows() {
  const STUDENT_ID = '2082094'; // ← change this

  const rows = readVaultSheetAsObjects_(VAULT_SHEET_TRANSCRIPT_ROWS, VAULT_TRANSCRIPT_HEADERS);
  const studentRows = rows.filter(r => String(r.studentId || '').trim() === String(STUDENT_ID).trim());

  if (!studentRows.length) {
    Logger.log('No transcript rows found for studentId "' + STUDENT_ID + '".');
    const idsOnFile = [...new Set(rows.map(r => String(r.studentId || '').trim()))];
    Logger.log('Sample studentIds on file (first 20): ' + idsOnFile.slice(0, 20).join(', '));
    return;
  }

  Logger.log('Transcript rows for studentId ' + STUDENT_ID + ': ' + studentRows.length);
  Logger.log('');
  studentRows.forEach((r, i) => {
    Logger.log('Row ' + (i + 1) + ': ' + JSON.stringify(r));
  });
}

// ── Course Sync ───────────────────────────────────────────────
// debugSyncSkipped and debugSyncSingleStudent live in CourseSync.gs
// since they're directly tied to the sync process.

// ── TABE ─────────────────────────────────────────────────────

// Logs a summary of TABE data for a specific student.
function debugTABEStudent() {
  const STUDENT_NAME = 'Last, First'; // ← change this

  const data = getDashboardData();
  if (data.error) { Logger.log('ERROR: ' + data.error); return; }

  const profile = (data.profiles || []).find(p =>
    p.displayName.toLowerCase() === STUDENT_NAME.toLowerCase()
  );

  if (!profile) { Logger.log('Profile not found: ' + STUDENT_NAME); return; }
  if (!profile.tabe) { Logger.log(STUDENT_NAME + ' has no TABE data on file.'); return; }

  const t = profile.tabe;
  Logger.log('=== TABE: ' + profile.displayName + ' ===');
  Logger.log('HSD Status: ' + t.hsdStatus);
  Logger.log('Report Date: ' + t.reportDate);

  ['math', 'reading'].forEach(subject => {
    const sub = t[subject];
    if (!sub) { Logger.log(subject + ': no data'); return; }
    Logger.log('');
    Logger.log(subject.toUpperCase() + ':');
    Logger.log('  Attempts: ' + sub.attempts);
    Logger.log('  Current:  scale=' + sub.current.scale + ' | EFL=' + sub.current.efl + ' | date=' + sub.current.date);
    if (sub.previous) {
      Logger.log('  Previous: scale=' + sub.previous.scale + ' | EFL=' + sub.previous.efl + ' | date=' + sub.previous.date);
    }
    Logger.log('  Best:     scale=' + sub.best.scale + ' | EFL=' + sub.best.efl + ' | date=' + sub.best.date);
    Logger.log('  Gain:     ' + sub.gain);
  });
}

// Runs the TABE gain-prediction model and logs the top 10 in each subject.
function debugTABEGainPredictions_dashboard() {
  const result = getTABEGainPredictions(10);
  if (result.error) { Logger.log('ERROR: ' + result.error); return; }
  Logger.log('=== TOP 10 READING ===');
  result.reading.forEach((s, i) =>
    Logger.log((i+1) + '. ' + s.name + ' — Level ' + s.currentLevel + ' (' + s.currentScale +
      ') → Level ' + s.nextLevel + ' | needs +' + s.pointsToNext +
      ' | rate: ' + s.weeklyRate + ' pts/wk | ~' + s.predictedWeeks + ' wks'));
  Logger.log('=== TOP 10 MATH ===');
  result.math.forEach((s, i) =>
    Logger.log((i+1) + '. ' + s.name + ' — Level ' + s.currentLevel + ' (' + s.currentScale +
      ') → Level ' + s.nextLevel + ' | needs +' + s.pointsToNext +
      ' | rate: ' + s.weeklyRate + ' pts/wk | ~' + s.predictedWeeks + ' wks'));
}

// Reads VAULT_SHEET_TABE_HISTORY directly and reports how many
// student+subject combos actually have 2+ tests on file — the
// minimum needed for a gain calculation.
//
// NOTE: TABE_HISTORY_HEADERS (Config.gs) uses human-readable column
// names ('Student ID', 'Scale Score', etc.), NOT camelCase like most
// other Vault headers — readVaultSheetAsObjects_ uses header strings
// verbatim as object keys, so field access below uses bracket
// notation with the literal header text.
function debugGainPredictions() {
  const result = getTABEGainPredictions(10);
  Logger.log('Error: ' + (result.error || 'none'));
  Logger.log('Reading: ' + (result.reading || []).length);
  Logger.log('Math: ' + (result.math || []).length);

  const rows = readVaultSheetAsObjects_(VAULT_SHEET_TABE_HISTORY, TABE_HISTORY_HEADERS);
  if (!rows.length) { Logger.log('TABE History sheet has no rows.'); return; }
  Logger.log('TABE History rows: ' + rows.length);

  const grouped = {};
  rows.forEach(r => {
    const key = String(r['Student ID'] || '').trim() + '||' + String(r['Subject'] || '').trim();
    grouped[key] = (grouped[key] || 0) + 1;
  });
  const usable = Object.values(grouped).filter(c => c >= 2).length;
  Logger.log('Student+subject combos with 2+ tests: ' + usable);
}

// Picks the first student+subject combo with 2+ tests on file and
// walks through date parsing / level lookup step by step.
function debugGainSingleStudent() {
  const rows = readVaultSheetAsObjects_(VAULT_SHEET_TABE_HISTORY, TABE_HISTORY_HEADERS);
  if (!rows.length) { Logger.log('TABE History sheet has no rows.'); return; }

  const grouped = {};
  rows.forEach(r => {
    const key = String(r['Student ID'] || '').trim() + '||' + String(r['Subject'] || '').trim();
    if (!grouped[key]) grouped[key] = [];
    grouped[key].push(r);
  });

  const usable = Object.entries(grouped).find(([k, v]) => v.length >= 2);
  if (!usable) { Logger.log('No usable combos found'); return; }

  const [key, tests] = usable;
  Logger.log('Testing with: ' + key);
  Logger.log('Tests: ' + JSON.stringify(tests));

  tests.forEach(t => {
    const ms = _tabeParseDate(String(t['Test Date']));
    Logger.log('Date "' + t['Test Date'] + '" -> ms: ' + ms);
  });

  const scale   = Number(tests[tests.length - 1]['Scale Score']);
  const subject = String(tests[0]['Subject']).trim();
  Logger.log('Subject: "' + subject + '" Scale: ' + scale);
  Logger.log('TABE_THRESHOLDS keys: ' + Object.keys(TABE_THRESHOLDS).join(', '));
  const level = _tabeLevelForScore(subject, scale);
  Logger.log('Level for score: ' + level);
  const next = _tabeNextThreshold(subject, level);
  Logger.log('Next threshold: ' + next);
}

// Checks how many student+subject combos have genuinely distinct
// test dates on file (guards against duplicate-import rows being
// mistaken for real repeat testing).
function debugHistoryDateSpread() {
  const rows = readVaultSheetAsObjects_(VAULT_SHEET_TABE_HISTORY, TABE_HISTORY_HEADERS);
  if (!rows.length) { Logger.log('TABE History sheet has no rows.'); return; }

  const grouped = {};
  rows.forEach(r => {
    const key = String(r['Student ID'] || '').trim() + '||' + String(r['Subject'] || '').trim();
    if (!grouped[key]) grouped[key] = new Set();
    const raw = r['Test Date'];
    const d = raw instanceof Date ? raw.getTime() : String(raw);
    grouped[key].add(d + '|' + r['Scale Score']);
  });

  const uniqueCounts = Object.values(grouped).map(s => s.size);
  const withTwo = uniqueCounts.filter(c => c >= 2).length;
  const withOne = uniqueCounts.filter(c => c === 1).length;
  Logger.log('Combos with 2+ UNIQUE test dates: ' + withTwo);
  Logger.log('Combos with only 1 unique test date: ' + withOne);
}

// ── WIR ──────────────────────────────────────────────────────

// Logs a summary of WIR data from the latest Vault WIR Reports sheet.
function debugWIRData() {
  const wirData = getWIRData();
  if (!wirData) { Logger.log('No WIR data found.'); return; }

  Logger.log('WIR Sheet: ' + wirData.sheetName);
  Logger.log('Week Label: ' + wirData.weekLabel);
  Logger.log('Rows: ' + wirData.rows.length);
  Logger.log('');

  const critical = wirData.rows.filter(r => (r.adminPriority || '').toUpperCase() === 'CRITICAL');
  const high     = wirData.rows.filter(r => (r.adminPriority || '').toUpperCase() === 'HIGH');
  Logger.log('CRITICAL: ' + critical.length);
  Logger.log('HIGH: ' + high.length);

  critical.slice(0, 5).forEach(r => {
    Logger.log('  CRITICAL: ' + r.student + ' | ' + r.urgency + ' | ' + r.reason);
  });
}

// ── Overrides ─────────────────────────────────────────────────

// Logs all current overrides in the Vault "Overrides And Notes" sheet.
function debugOverrides() {
  const sheet = _ensureVaultOverridesSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) { Logger.log('No overrides on file.'); return; }

  const values = sheet.getRange(2, 1, lastRow - 1, 6).getValues();
  Logger.log('Total override rows: ' + values.length);
  Logger.log('');

  const byType = {};
  values.forEach(row => {
    const type = String(row[1] || '').trim();
    if (!byType[type]) byType[type] = 0;
    byType[type]++;
  });

  Logger.log('By type:');
  Object.entries(byType).sort((a, b) => b[1] - a[1]).forEach(([type, count]) => {
    Logger.log('  ' + type + ': ' + count);
  });
}

function debugProductivityPayload_dashboard() {
  const payload = getProductivityPayload();
  Logger.log('Error: ' + (payload.error || 'none'));
  Logger.log('productivityData length: ' + (payload.productivityData || []).length);
  Logger.log('productivityCohort length: ' + (payload.productivityCohort || []).length);
  Logger.log('rosterNames length: ' + (payload.rosterNames || []).length);

  const first = (payload.productivityData || [])[0];
  if (first) {
    Logger.log('First student: ' + first.name);
    Logger.log('First week raw: ' + JSON.stringify(first.weeks[0]));
    Logger.log('overallProductivity: ' + first.overallProductivity);
  } else {
    Logger.log('productivityData is EMPTY');
  }

  const firstCohort = (payload.productivityCohort || [])[0];
  Logger.log('First cohort week: ' + JSON.stringify(firstCohort));
  Logger.log('First rosterName: ' + (payload.rosterNames || [])[0]);

  // Check what the dropdown would see
  const data = payload.productivityData || [];
  const roster = new Set(payload.rosterNames || []);
  const wouldShow = data.filter(s => {
    if (!s.name) return false;
    if (!roster.size) return true;
    const norm = s.name.toLowerCase().replace(/[^a-z ]/g, '').trim().split(' ').filter(Boolean).sort().join(' ');
    return roster.has(norm);
  });
  Logger.log('Students that would appear in dropdown: ' + wouldShow.length);
  if (wouldShow.length) Logger.log('First dropdown student: ' + wouldShow[0].name);
  if (!wouldShow.length && data.length) {
    Logger.log('MISMATCH — sample productivityData name norm: ' +
      data[0].name.toLowerCase().replace(/[^a-z ]/g, '').trim().split(' ').filter(Boolean).sort().join(' '));
    Logger.log('Sample rosterName: ' + [...roster][0]);
  }
}

function debugGainsSnapshot() {
  const result = getLatestTABEGainSnapshot();
  Logger.log('Error: ' + (result.error || 'none'));
  Logger.log('snapshotDate: ' + result.snapshotDate);
  Logger.log('reading length: ' + (result.reading || []).length);
  Logger.log('math length: ' + (result.math || []).length);
}

function debugGraduatesQuick() {
  const result = getHSGraduationPredictions();
  Logger.log('Error: ' + (result.error || 'none'));
  Logger.log('graduates length: ' + (result.graduates || []).length);
  Logger.log('month: ' + result.month);
}

function debugGraduationDates() {
  const data = getDashboardData();
  const hs = (data.profiles || []).filter(p =>
    p.academic && p.academic.type === 'HS' && !p.hsComplete
  );
  Logger.log('Active HS students: ' + hs.length);

  const today = new Date();
  const twoMonths = new Date(today.getFullYear(), today.getMonth() + 2, today.getDate());

  let withGrad = 0, withinWindow = 0;
  hs.forEach(p => {
    if (p.academic.graduation) withGrad++;
    const d = p.academic.graduation ? new Date(p.academic.graduation) : null;
    if (d && d <= twoMonths) {
      withinWindow++;
      Logger.log(p.displayName + ' | grad: ' + p.academic.graduation + ' | credits: ' + p.academic.credits + ' | %: ' + p.academic.percent);
    }
  });
  Logger.log('With graduation date: ' + withGrad);
  Logger.log('Within 2-month window: ' + withinWindow);
}

function debugGraduateCards() {
  const result = getHSGraduationPredictions();
  const g = result.graduates[0];
  if (!g) { Logger.log('No graduates'); return; }
  Logger.log('Full first graduate: ' + JSON.stringify(g));
}

// ── Monthly Progress (HS / Trade) ──────────────────────────────

function debugMonthlyAndGains() {
  // Check monthly cohort data
  const payload = getProductivityPayload();
  Logger.log('hsMonthlyCohort length: ' + (payload.hsMonthlyCohort || []).length);
  Logger.log('tradeMonthlyCohort length: ' + (payload.tradeMonthlyCohort || []).length);
  if ((payload.hsMonthlyCohort || []).length) {
    Logger.log('First HS month: ' + JSON.stringify(payload.hsMonthlyCohort[0]));
  }
  if ((payload.tradeMonthlyCohort || []).length) {
    Logger.log('First trade month: ' + JSON.stringify(payload.tradeMonthlyCohort[0]));
  }

  // Check gains snapshot
  const gains = getLatestTABEGainSnapshot();
  Logger.log('Gains error: ' + (gains.error || 'none'));
  Logger.log('Gains reading length: ' + (gains.reading || []).length);
  Logger.log('Gains math length: ' + (gains.math || []).length);
  if ((gains.reading || []).length) {
    Logger.log('First reading entry: ' + JSON.stringify(gains.reading[0]));
  }
}

// Rebuilds the HS/trade monthly cohorts directly from the Vault
// Academic Snapshots / Trade Snapshots sheets — bypasses the cached
// dashboard payload so you can see raw output from
// buildHSMonthlyCohortFromVault_ / getTradeMonthlyCohortSummaryFromVault_.
function debugMonthlyCohortDirect() {
  const academicSnapshotRows = readVaultSheetAsObjects_(VAULT_SHEET_ACADEMIC_SNAPSHOTS, VAULT_ACADEMIC_SNAPSHOT_HEADERS);
  const tradeSnapshotRows    = readVaultSheetAsObjects_(VAULT_SHEET_TRADE_SNAPSHOTS, VAULT_TRADE_SNAPSHOT_HEADERS);
  const nameMap              = readVaultSheetAsObjects_(VAULT_SHEET_NAME_MAPPING, VAULT_NAME_MAPPING_HEADERS);

  Logger.log('academicSnapshotRows length: ' + academicSnapshotRows.length);
  Logger.log('tradeSnapshotRows length: ' + tradeSnapshotRows.length);

  const hsResult = buildHSMonthlyCohortFromVault_(academicSnapshotRows);
  Logger.log('hsMonthlyCohort result length: ' + (hsResult.cohort || []).length);
  if (hsResult.cohort && hsResult.cohort.length) Logger.log('First: ' + JSON.stringify(hsResult.cohort[0]));
  Logger.log('hsMonthlyByStudent count: ' + Object.keys(hsResult.byStudent || {}).length);

  const tradeCohort = getTradeMonthlyCohortSummaryFromVault_(tradeSnapshotRows, nameMap);
  Logger.log('tradeMonthlyCohort result length: ' + (tradeCohort || []).length);
  if (tradeCohort && tradeCohort.length) Logger.log('First: ' + JSON.stringify(tradeCohort[0]));
}

// Forces a fresh dashboard rebuild (clearing caches first) and logs
// the monthly cohort output actually returned to the client.
function debugMonthlyPayload() {
  debugForceFullClear();
  const payload = getProductivityPayload();
  Logger.log('hsMonthlyCohort length: ' + (payload.hsMonthlyCohort || []).length);
  Logger.log('tradeMonthlyCohort length: ' + (payload.tradeMonthlyCohort || []).length);
  if ((payload.hsMonthlyCohort || []).length) {
    Logger.log('First HS month: ' + JSON.stringify(payload.hsMonthlyCohort[0]));
  } else {
    Logger.log('hsMonthlyCohort is empty or missing');
  }
}

// Logs every Academic Snapshots row for a given student — Vault
// replacement for the old "raw row in the HS Monthly matrix sheet"
// inspector. That matrix sheet no longer exists; Academic Snapshots
// is one flat row per student per month instead.
function debugStudentAcademicSnapshots(studentNameFragment) {
  const nameMap = readVaultSheetAsObjects_(VAULT_SHEET_NAME_MAPPING, VAULT_NAME_MAPPING_HEADERS);
  const match = nameMap.find(r =>
    String(r.masterName || '').toLowerCase().includes(String(studentNameFragment).toLowerCase())
  );
  if (!match) {
    Logger.log('No Name Mapping row found matching "' + studentNameFragment + '".');
    return;
  }

  const studentId = String(match.studentId || '').trim();
  Logger.log('Matched: ' + match.masterName + ' (studentId ' + studentId + ')');

  const rows = readVaultSheetAsObjects_(VAULT_SHEET_ACADEMIC_SNAPSHOTS, VAULT_ACADEMIC_SNAPSHOT_HEADERS);
  const studentRows = rows.filter(r => String(r.studentId || '').trim() === studentId);

  Logger.log('Academic Snapshot rows for this student: ' + studentRows.length);
  studentRows.forEach(r => Logger.log('  ' + JSON.stringify(r)));
}

// Convenience wrapper — update the fragment and run this one.
function _runDebugStudentAcademicSnapshots() {
  debugStudentAcademicSnapshots('Robinson'); // ← put a real last name here
}

// ── Bulk Pacing ────────────────────────────────────────────────

function debugScanAllStudentPacing() {
  try {
    Logger.log("Starting scan...");
    const result = scanAllStudentPacing();
    Logger.log(JSON.stringify(result, null, 2));
  } catch (e) {
    Logger.log("ERROR:");
    Logger.log(e);
    Logger.log(e.stack);
  }
}

function debugTestScanAllStudentPacing() {
  const start = new Date().getTime();
  Logger.log('debugTestScanAllStudentPacing: starting at ' + new Date().toISOString());

  try {
    const result = scanAllStudentPacing();
    const elapsedMs = new Date().getTime() - start;

    if (!result || result.success === false) {
      Logger.log('FAILED after ' + elapsedMs + 'ms');
      Logger.log('Result: ' + JSON.stringify(result, null, 2));
      return;
    }

    const students = result.students || [];
    Logger.log('SUCCESS in ' + elapsedMs + 'ms (' + (elapsedMs / 1000).toFixed(1) + 's)');
    Logger.log('Students returned: ' + students.length);

    // Break down by status so you can see if it's mostly "no_schedule"
    // (meaning schedule reads are failing silently) vs a healthy mix
    const statusCounts = {};
    students.forEach(s => {
      statusCounts[s.status] = (statusCounts[s.status] || 0) + 1;
    });
    Logger.log('Status breakdown: ' + JSON.stringify(statusCounts));

    // Log first 3 students in full so you can eyeball the shape of the data
    Logger.log('Sample (first 3 students): ' + JSON.stringify(students.slice(0, 3), null, 2));

  } catch (err) {
    const elapsedMs = new Date().getTime() - start;
    Logger.log('THREW EXCEPTION after ' + elapsedMs + 'ms');
    Logger.log('Error message: ' + err.message);
    Logger.log('Stack: ' + err.stack);
  }
}

// ------------------------------------------------------------
// Time just the schedule-reading portion in isolation, if
// scanAllStudentPacing() itself succeeds but is slow.
// ------------------------------------------------------------
function debugTimeSingleStudentScheduleRead() {

  const testStudentId = '2082094';

  const start = new Date().getTime();
  try {
    const result = getStudentSchedule(testStudentId);
    const elapsedMs = new Date().getTime() - start;
    Logger.log('Single student schedule read: ' + elapsedMs + 'ms');
    Logger.log('Result: ' + JSON.stringify(result, null, 2));
  } catch (err) {
    const elapsedMs = new Date().getTime() - start;
    Logger.log('THREW after ' + elapsedMs + 'ms: ' + err.message);
    Logger.log('Stack: ' + err.stack);
  }
}
function debugStudentTradeProficiency(studentId) {
  const result = getStudentTradeProficiency(studentId || '2083267'); // ← swap to a real student
  Logger.log(JSON.stringify(result, null, 2));
}
function debugStudentTimeLog(studentId) {
  const result = getStudentTimeLog(studentId || '2083267'); // ← swap to a real student
  Logger.log(JSON.stringify(result, null, 2));
}

function debugTimeLogForRealStudents() {
  const testIds = ['2082094', '2074786', '1954905', 'NOT_A_REAL_ID'];
  testIds.forEach(id => {
    const result = getStudentTimeLog(id);
    Logger.log('studentId=' + id + ' -> ' + JSON.stringify(result));
  });
}
function debugTimeLogFor2078852() {
  const result = getStudentTimeLog('2078852');
  Logger.log('Direct call result: ' + JSON.stringify(result));
  Logger.log('weeks.length = ' + (result.weeks ? result.weeks.length : 'N/A'));
}
function debugCheckExamProgram() {
  const result = getDashboardData(); // or whatever your main data function is called
  const student = result.profiles.find(p => p.displayName.includes('Burkholder'));
  Logger.log(JSON.stringify({ id: student.id, examProgram: student.examProgram }));
}
// server-side debug function, run from Apps Script editor
function debugCheckActionViewFields() {
  const result = getDashboardData();
  const sample = result.profiles.slice(0, 5).map(p => ({
    name: p.displayName,
    hasIntervention: p.hasIntervention,
    adminPriority: p.intervention?.adminPriority,
    gradGap: p.intervention?.gradGap,
    followUp: p.intervention?.followUp,
    hasAcademic: p.hasAcademic,
    thisWeekHours: p.academic?.thisWeekHours,
    isStale: p.isStale,
  }));
  Logger.log(JSON.stringify(sample, null, 2));
}

// ── Trade Snapshots ────────────────────────────────────────────

// Read-only — shows what generateTradeSnapshot('weekly', ...) WOULD
// do without writing anything, so you can sanity-check before the
// real run. Run this with no arguments directly from the editor.
function debugTradeSnapshotDryRun() {
  const nameMap = readVaultSheetAsObjects_(VAULT_SHEET_NAME_MAPPING, VAULT_NAME_MAPPING_HEADERS);
  const activeIds = new Set(
    nameMap
      .filter(m => m.active === true || String(m.active).trim().toUpperCase() === 'TRUE')
      .map(m => String(m.studentId || '').trim())
  );
  Logger.log('Active students in Name Mapping: ' + activeIds.size);

  const tradeOverviewRows = readVaultSheetAsObjects_(VAULT_SHEET_TRADE_OVERVIEW, VAULT_TRADE_OVERVIEW_HEADERS);
  Logger.log('Total Trade Overview rows: ' + tradeOverviewRows.length);

  let wouldWrite = 0, noStudentOrTrade = 0, inactiveSkip = 0, noPercentSkip = 0;
  tradeOverviewRows.forEach(row => {
    const id    = String(row.studentId || '').trim();
    const trade = String(row.trade || '').trim();
    if (!id || !trade) { noStudentOrTrade++; return; }
    if (!activeIds.has(id)) { inactiveSkip++; return; }
    const pct = row.overallPercent;
    if (pct === '' || pct === undefined || pct === null || isNaN(Number(pct))) { noPercentSkip++; return; }
    wouldWrite++;
  });

  Logger.log('Would write (active, has trade+percent): ' + wouldWrite);
  Logger.log('Skipped — missing studentId or trade: ' + noStudentOrTrade);
  Logger.log('Skipped — inactive/archived student: ' + inactiveSkip);
  Logger.log('Skipped — no valid overallPercent: ' + noPercentSkip);

  const existing = readVaultSheetAsObjects_(VAULT_SHEET_TRADE_SNAPSHOTS, VAULT_TRADE_SNAPSHOT_HEADERS);
  Logger.log('Existing rows already in Trade Snapshots: ' + existing.length);
}

// Actually calls generateTradeSnapshot with explicit arguments (the
// real function returns nothing visible if run bare from the editor,
// since running a function directly passes no arguments and the
// cadence check fails silently before this fix). Logs the full result.
function debugTradeSnapshot() {
  const result = generateTradeSnapshot('weekly', null, 'debug');
  Logger.log('generateTradeSnapshot result: ' + JSON.stringify(result, null, 2));
}
function debugHSMonthlySource() {
  const ss = SpreadsheetApp.getActive();

  console.log("Sheets:");
  ss.getSheets().forEach(s => {
    console.log(s.getName());
  });

  const props = PropertiesService.getScriptProperties()
    .getProperties();

  console.log("Script Properties:");
  console.log(JSON.stringify(props, null, 2));
}